#!/bin/bash
python3 td_0.py "$@"
