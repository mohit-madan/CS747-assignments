#!/bin/bash
./evaluator.sh ../data/d1.txt
#./evaluator.sh ../data/d2.txt

