#!/bin/bash

python3 WindWorld.py "$@"
